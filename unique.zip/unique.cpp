/*******************************************************************************
 * Name        : unique.cpp
 * Author      : Roma Razdan
 * Date        : Septemeber 18th, 2020
 * Description : Determining uniqueness of chars with int as bit vector.
 * Pledge      : I pledge my honor that I have abided by the Stevens Honor System.
 ******************************************************************************/
#include <iostream>
#include <cctype>

using namespace std;

bool is_all_lowercase(const string &s)
{
    // returns true if all characters in string are lowercase letters in the English alphabet
	// false otherwise
    for(unsigned int i = 0; i < s.length(); i++){
		if (!islower(s[i])){
			return false;
		}
	}
	return true;
}

bool all_unique_letters(const string &s) {
    // returns true if all letters in string are unique; false otherwise.
    if (s.length() == 0){
        return true;
    }
	 unsigned int i = 0;
	 //looking for non-uniques
	 for (unsigned int j =0; j < s.length(); j++){
		 //97 cause lang
		 int value = s[j] - 97;
		 if ((i & (1 << value)) > 0){
             return false;
         }
		 i = i | (1 << value);
	 }
	 //otherwise unique
	 return true;
}

int main(int argc, char * const argv[]) {
    // reads and parses command line arguments.
    // calls other functions to produce correct output.
    if(argc != 2){
    	cout << "Usage: ./unique <string>" << endl;
		return 1;
	}
	if(argc == 2){
		//checks if lowercase
		if(!is_all_lowercase(string(argv[1]))){
			cout << "Error: String must contain only lowercase letters." << endl;
			return 1;
		}
		//checks if unique
        else if(!all_unique_letters(string(argv[1]))){
			cout << "Duplicate letters found."<< endl;
			return 1;
		}
		//otherwise lowercase and unique
        else{
			cout << "All letters are unique." << endl;
			return 0;
		}
	}
}
