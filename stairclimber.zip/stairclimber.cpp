/*******************************************************************************
 * Name        : stairclimber.cpp
 * Author      : Roma Razdan
 * Date        : October 2nd 2020
 * Description : Lists the number of ways to climb n stairs.
 * Pledge      : I pledge my honor that I have abided by the Stevens Honor System.
 ******************************************************************************/

#include <iostream>
#include <vector>
#include <algorithm>
#include <sstream>
#include <iomanip>

using namespace std;

vector< vector<int> > get_ways(int num_stairs) {
    // returns a vector of vectors of ints
	// representing the different combinations of ways to climb num_stairs stairs,
	// moving up either 1, 2, or 3 stairs at a time.
	vector<vector<int>> ways;
	vector<vector<int>> range;
	// if stair num is less than or equal to zero
	// push val
	if (num_stairs <= 0){
		ways.push_back(vector<int>());
		return ways;
	}
	// otherwise find combo
	else{
		for(int i = 1; i <= 3; i++){
			if(num_stairs >= i){
				range = get_ways(num_stairs - i);
				for(unsigned int j = 0; j < range.size(); j++){
					range[j].push_back(i);
					ways.push_back(range[j]);
				}
			}
		}
		return ways;
	}
}

void display_ways(const vector< vector<int> > &ways) {
    // displays the ways to climb stairs by iterating over
    // the vector of vectors and printing each combination.
	unsigned int value, temp;
	// determines temp based on interations of ways
	for(unsigned int i = 0; i < ways.size(); i++){
		temp = ways.size();
		value = 1;
		while(temp >= 10){
			value++;
			temp = temp / 10;
		}
		cout << setw(value) << i + 1 << ". " << "[";
		// displays diff pathways
		for(unsigned int j = ways[i].size() - 1; j >= 1; j--){
			cout << ways[i][j] << ", ";
		}
		cout << ways[i][0] << "]" << endl;
	}
}

int main(int argc, char * const argv[]) {
    int limit;
    istringstream iss;
    // check if argc is not equal to 2, then return
    if(argc != 2){
		cout << "Usage: ./stairclimber <number of stairs>" << endl;
		return 1;
	}
    iss.str(argv[1]);
    // check if stairs are negative (below 0)
    if ( !(iss >> limit) || limit < 1){
        cerr << "Error: Number of stairs must be a positive integer." << endl;
        return 1;
    }
    // lim is valid
    // call get_ways and determine num ways
    vector< vector<int> > value = get_ways(limit);
    if(limit == 1){
        cout << limit << " way to climb " << limit << " stair." << endl;
    }
    else{
        cout << value.size() << " ways to climb " << limit << " stairs." << endl;
    }
    display_ways(value);
    iss.clear();
    return 0;
}
